
function datampdf{

var tempo = new Date().toLocaleDateString();

document.getElementById("data").innerHTML = tempo;  }
